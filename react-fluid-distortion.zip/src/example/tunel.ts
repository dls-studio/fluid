import tunnel from 'tunnel-rat';

export const ThreeTunnel = tunnel();
